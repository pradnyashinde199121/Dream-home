
         
         $(document).ready(function(){
             
             $("#button").click(function(){
                 
                 $( "#show" ).show();
             });
             $("#button1").click(function(){
                 
                 $( "#show1" ).show();
             });
             $("#button2").click(function(){
                 
                 $( "#show2" ).show();
             });
         });
     